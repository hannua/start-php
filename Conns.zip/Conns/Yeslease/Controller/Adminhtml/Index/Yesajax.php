<?php

namespace Conns\Yeslease\Controller\Adminhtml\Index;

use Magento\Backend\App\Action;
use Magento\Framework\Controller\Result\Raw;
use Magento\Framework\Controller\ResultFactory;
 
class Yesajax extends \Magento\Framework\App\Action\Action
{
    public function __construct(
        \Magento\Framework\App\Action\Context $context)
    {
        return parent::__construct($context);
    }

    public function execute()
    {
	    $this->_view->loadLayout();
		$this->_view->getLayout()->initMessages();
        $this->_view->renderLayout();
        
    }
}