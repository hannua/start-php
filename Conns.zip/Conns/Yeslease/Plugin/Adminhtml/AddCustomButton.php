<?php
   
    namespace Conns\Yeslease\Plugin\Adminhtml;
    
    
    class AddCustomButton
    {
        
        public function beforePushButtons(
                                          \Magento\Backend\Block\Widget\Button\Toolbar\Interceptor $subject,
                                          \Magento\Framework\View\Element\AbstractBlock $context,
                                          \Magento\Backend\Block\Widget\Button\ButtonList $buttonList
                                          )
        {
            if ($context->getRequest()->getFullActionName() == 'sales_order_view') {
                $url = $context->getUrl('conns_yeslease/order/index');
                $buttonList->add(
                                 'customButton',
                                 ['label' => __('Verify Yeslease'), 'onclick' => 'setLocation("' . $url . '")', 'class' => 'reset'],
                                 -1
                                 );
            }
        }
    }
