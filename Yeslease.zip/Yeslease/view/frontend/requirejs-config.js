var config = {
    map: {
        "*":{
         customValidationMethod: "Conns_Yeslease/js/customValidationRule"
            }
        }
             };