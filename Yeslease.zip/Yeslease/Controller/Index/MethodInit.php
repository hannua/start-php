<?php

namespace Conns\Yeslease\Controller\Payment;

use Magento\Framework\App\Action\Context;
use Magento\Framework\Controller\Result\JsonFactory;

class MethodInit extends \Magento\Framework\App\Action\Action
{
  echo "success"
    }

}